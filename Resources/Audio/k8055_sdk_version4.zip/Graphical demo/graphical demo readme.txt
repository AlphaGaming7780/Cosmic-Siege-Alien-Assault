K8055 USB experiment board.
---------------------------

Demo written in VB for demonstrating purposes.

Source code is supplied.

