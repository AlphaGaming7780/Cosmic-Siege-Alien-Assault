﻿namespace K8055Demo
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.CheckBox16 = new System.Windows.Forms.CheckBox();
            this.CheckBox3 = new System.Windows.Forms.CheckBox();
            this.Label1 = new System.Windows.Forms.Label();
            this.CheckBox15 = new System.Windows.Forms.CheckBox();
            this.GroupBox5 = new System.Windows.Forms.GroupBox();
            this.RadioButton5 = new System.Windows.Forms.RadioButton();
            this.RadioButton6 = new System.Windows.Forms.RadioButton();
            this.RadioButton7 = new System.Windows.Forms.RadioButton();
            this.RadioButton8 = new System.Windows.Forms.RadioButton();
            this.Label3 = new System.Windows.Forms.Label();
            this.Button3 = new System.Windows.Forms.Button();
            this.TextBox2 = new System.Windows.Forms.TextBox();
            this.CheckBox14 = new System.Windows.Forms.CheckBox();
            this.CheckBox12 = new System.Windows.Forms.CheckBox();
            this.Button1 = new System.Windows.Forms.Button();
            this.CheckBox13 = new System.Windows.Forms.CheckBox();
            this.CheckBox11 = new System.Windows.Forms.CheckBox();
            this.GroupBox2 = new System.Windows.Forms.GroupBox();
            this.CheckBox10 = new System.Windows.Forms.CheckBox();
            this.CheckBox9 = new System.Windows.Forms.CheckBox();
            this.Label9 = new System.Windows.Forms.Label();
            this.Button9 = new System.Windows.Forms.Button();
            this.Timer1 = new System.Windows.Forms.Timer(this.components);
            this.Button8 = new System.Windows.Forms.Button();
            this.RadioButton12 = new System.Windows.Forms.RadioButton();
            this.GroupBox10 = new System.Windows.Forms.GroupBox();
            this.Label8 = new System.Windows.Forms.Label();
            this.RadioButton11 = new System.Windows.Forms.RadioButton();
            this.RadioButton10 = new System.Windows.Forms.RadioButton();
            this.RadioButton9 = new System.Windows.Forms.RadioButton();
            this.GroupBox3 = new System.Windows.Forms.GroupBox();
            this.CheckBox2 = new System.Windows.Forms.CheckBox();
            this.CheckBox1 = new System.Windows.Forms.CheckBox();
            this.Label4 = new System.Windows.Forms.Label();
            this.GroupBox9 = new System.Windows.Forms.GroupBox();
            this.Label7 = new System.Windows.Forms.Label();
            this.VScrollBar4 = new System.Windows.Forms.VScrollBar();
            this.GroupBox8 = new System.Windows.Forms.GroupBox();
            this.Label6 = new System.Windows.Forms.Label();
            this.VScrollBar3 = new System.Windows.Forms.VScrollBar();
            this.VScrollBar1 = new System.Windows.Forms.VScrollBar();
            this.GroupBox7 = new System.Windows.Forms.GroupBox();
            this.Label5 = new System.Windows.Forms.Label();
            this.VScrollBar2 = new System.Windows.Forms.VScrollBar();
            this.GroupBox6 = new System.Windows.Forms.GroupBox();
            this.Button7 = new System.Windows.Forms.Button();
            this.Button5 = new System.Windows.Forms.Button();
            this.Button6 = new System.Windows.Forms.Button();
            this.RadioButton4 = new System.Windows.Forms.RadioButton();
            this.RadioButton3 = new System.Windows.Forms.RadioButton();
            this.RadioButton2 = new System.Windows.Forms.RadioButton();
            this.RadioButton1 = new System.Windows.Forms.RadioButton();
            this.Label2 = new System.Windows.Forms.Label();
            this.Button2 = new System.Windows.Forms.Button();
            this.TextBox1 = new System.Windows.Forms.TextBox();
            this.Button4 = new System.Windows.Forms.Button();
            this.Timer2 = new System.Windows.Forms.Timer(this.components);
            this.GroupBox1 = new System.Windows.Forms.GroupBox();
            this.CheckBox8 = new System.Windows.Forms.CheckBox();
            this.CheckBox7 = new System.Windows.Forms.CheckBox();
            this.CheckBox6 = new System.Windows.Forms.CheckBox();
            this.CheckBox5 = new System.Windows.Forms.CheckBox();
            this.CheckBox4 = new System.Windows.Forms.CheckBox();
            this.GroupBox4 = new System.Windows.Forms.GroupBox();
            this.GroupBox5.SuspendLayout();
            this.GroupBox2.SuspendLayout();
            this.GroupBox10.SuspendLayout();
            this.GroupBox3.SuspendLayout();
            this.GroupBox9.SuspendLayout();
            this.GroupBox8.SuspendLayout();
            this.GroupBox7.SuspendLayout();
            this.GroupBox6.SuspendLayout();
            this.GroupBox1.SuspendLayout();
            this.GroupBox4.SuspendLayout();
            this.SuspendLayout();
            // 
            // CheckBox16
            // 
            this.CheckBox16.Location = new System.Drawing.Point(230, 17);
            this.CheckBox16.Name = "CheckBox16";
            this.CheckBox16.Size = new System.Drawing.Size(26, 15);
            this.CheckBox16.TabIndex = 12;
            this.CheckBox16.Text = "8";
            this.CheckBox16.UseVisualStyleBackColor = true;
            this.CheckBox16.CheckedChanged += new System.EventHandler(this.CheckBox16_CheckedChanged);
            // 
            // CheckBox3
            // 
            this.CheckBox3.Appearance = System.Windows.Forms.Appearance.Button;
            this.CheckBox3.Location = new System.Drawing.Point(12, 283);
            this.CheckBox3.Name = "CheckBox3";
            this.CheckBox3.Size = new System.Drawing.Size(108, 24);
            this.CheckBox3.TabIndex = 44;
            this.CheckBox3.Text = "Output Test";
            this.CheckBox3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.CheckBox3.CheckedChanged += new System.EventHandler(this.CheckBox3_CheckedChanged);
            // 
            // Label1
            // 
            this.Label1.Location = new System.Drawing.Point(12, 84);
            this.Label1.Name = "Label1";
            this.Label1.Size = new System.Drawing.Size(104, 16);
            this.Label1.TabIndex = 42;
            this.Label1.Text = "- - -";
            // 
            // CheckBox15
            // 
            this.CheckBox15.Location = new System.Drawing.Point(198, 17);
            this.CheckBox15.Name = "CheckBox15";
            this.CheckBox15.Size = new System.Drawing.Size(26, 15);
            this.CheckBox15.TabIndex = 11;
            this.CheckBox15.Text = "7";
            this.CheckBox15.UseVisualStyleBackColor = true;
            this.CheckBox15.CheckedChanged += new System.EventHandler(this.CheckBox15_CheckedChanged);
            // 
            // GroupBox5
            // 
            this.GroupBox5.Controls.Add(this.RadioButton5);
            this.GroupBox5.Controls.Add(this.RadioButton6);
            this.GroupBox5.Controls.Add(this.RadioButton7);
            this.GroupBox5.Controls.Add(this.RadioButton8);
            this.GroupBox5.Controls.Add(this.Label3);
            this.GroupBox5.Controls.Add(this.Button3);
            this.GroupBox5.Controls.Add(this.TextBox2);
            this.GroupBox5.Location = new System.Drawing.Point(511, 123);
            this.GroupBox5.Name = "GroupBox5";
            this.GroupBox5.Size = new System.Drawing.Size(117, 184);
            this.GroupBox5.TabIndex = 53;
            this.GroupBox5.TabStop = false;
            this.GroupBox5.Text = "Counter2";
            // 
            // RadioButton5
            // 
            this.RadioButton5.AutoSize = true;
            this.RadioButton5.Location = new System.Drawing.Point(9, 90);
            this.RadioButton5.Name = "RadioButton5";
            this.RadioButton5.Size = new System.Drawing.Size(44, 17);
            this.RadioButton5.TabIndex = 6;
            this.RadioButton5.Text = "0ms";
            this.RadioButton5.UseVisualStyleBackColor = true;
            this.RadioButton5.CheckedChanged += new System.EventHandler(this.RadioButton5_CheckedChanged);
            // 
            // RadioButton6
            // 
            this.RadioButton6.AutoSize = true;
            this.RadioButton6.Checked = true;
            this.RadioButton6.Location = new System.Drawing.Point(9, 113);
            this.RadioButton6.Name = "RadioButton6";
            this.RadioButton6.Size = new System.Drawing.Size(44, 17);
            this.RadioButton6.TabIndex = 5;
            this.RadioButton6.TabStop = true;
            this.RadioButton6.Text = "2ms";
            this.RadioButton6.UseVisualStyleBackColor = true;
            this.RadioButton6.CheckedChanged += new System.EventHandler(this.RadioButton6_CheckedChanged);
            // 
            // RadioButton7
            // 
            this.RadioButton7.AutoSize = true;
            this.RadioButton7.Location = new System.Drawing.Point(9, 136);
            this.RadioButton7.Name = "RadioButton7";
            this.RadioButton7.Size = new System.Drawing.Size(50, 17);
            this.RadioButton7.TabIndex = 4;
            this.RadioButton7.Text = "10ms";
            this.RadioButton7.UseVisualStyleBackColor = true;
            this.RadioButton7.CheckedChanged += new System.EventHandler(this.RadioButton7_CheckedChanged);
            // 
            // RadioButton8
            // 
            this.RadioButton8.AutoSize = true;
            this.RadioButton8.Location = new System.Drawing.Point(9, 159);
            this.RadioButton8.Name = "RadioButton8";
            this.RadioButton8.Size = new System.Drawing.Size(62, 17);
            this.RadioButton8.TabIndex = 3;
            this.RadioButton8.Text = "1000ms";
            this.RadioButton8.UseVisualStyleBackColor = true;
            this.RadioButton8.CheckedChanged += new System.EventHandler(this.RadioButton8_CheckedChanged);
            // 
            // Label3
            // 
            this.Label3.Location = new System.Drawing.Point(6, 71);
            this.Label3.Name = "Label3";
            this.Label3.Size = new System.Drawing.Size(104, 16);
            this.Label3.TabIndex = 2;
            this.Label3.Text = "Debounce Time";
            // 
            // Button3
            // 
            this.Button3.Location = new System.Drawing.Point(6, 44);
            this.Button3.Name = "Button3";
            this.Button3.Size = new System.Drawing.Size(104, 24);
            this.Button3.TabIndex = 1;
            this.Button3.Text = "Reset";
            this.Button3.Click += new System.EventHandler(this.Button3_Click);
            // 
            // TextBox2
            // 
            this.TextBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TextBox2.Location = new System.Drawing.Point(6, 19);
            this.TextBox2.Name = "TextBox2";
            this.TextBox2.Size = new System.Drawing.Size(104, 20);
            this.TextBox2.TabIndex = 0;
            this.TextBox2.Text = "0";
            // 
            // CheckBox14
            // 
            this.CheckBox14.Location = new System.Drawing.Point(166, 17);
            this.CheckBox14.Name = "CheckBox14";
            this.CheckBox14.Size = new System.Drawing.Size(26, 15);
            this.CheckBox14.TabIndex = 10;
            this.CheckBox14.Text = "6";
            this.CheckBox14.UseVisualStyleBackColor = true;
            this.CheckBox14.CheckedChanged += new System.EventHandler(this.CheckBox14_CheckedChanged);
            // 
            // CheckBox12
            // 
            this.CheckBox12.Location = new System.Drawing.Point(102, 17);
            this.CheckBox12.Name = "CheckBox12";
            this.CheckBox12.Size = new System.Drawing.Size(26, 15);
            this.CheckBox12.TabIndex = 8;
            this.CheckBox12.Text = "4";
            this.CheckBox12.UseVisualStyleBackColor = true;
            this.CheckBox12.CheckedChanged += new System.EventHandler(this.CheckBox12_CheckedChanged);
            // 
            // Button1
            // 
            this.Button1.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.Button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Button1.Location = new System.Drawing.Point(12, 57);
            this.Button1.Name = "Button1";
            this.Button1.Size = new System.Drawing.Size(108, 24);
            this.Button1.TabIndex = 41;
            this.Button1.Text = "Connect";
            this.Button1.Click += new System.EventHandler(this.Button1_Click);
            // 
            // CheckBox13
            // 
            this.CheckBox13.Location = new System.Drawing.Point(134, 17);
            this.CheckBox13.Name = "CheckBox13";
            this.CheckBox13.Size = new System.Drawing.Size(26, 15);
            this.CheckBox13.TabIndex = 9;
            this.CheckBox13.Text = "5";
            this.CheckBox13.UseVisualStyleBackColor = true;
            this.CheckBox13.CheckedChanged += new System.EventHandler(this.CheckBox13_CheckedChanged);
            // 
            // CheckBox11
            // 
            this.CheckBox11.Location = new System.Drawing.Point(70, 17);
            this.CheckBox11.Name = "CheckBox11";
            this.CheckBox11.Size = new System.Drawing.Size(26, 15);
            this.CheckBox11.TabIndex = 7;
            this.CheckBox11.Text = "3";
            this.CheckBox11.UseVisualStyleBackColor = true;
            this.CheckBox11.CheckedChanged += new System.EventHandler(this.CheckBox11_CheckedChanged);
            // 
            // GroupBox2
            // 
            this.GroupBox2.Controls.Add(this.CheckBox16);
            this.GroupBox2.Controls.Add(this.CheckBox15);
            this.GroupBox2.Controls.Add(this.CheckBox14);
            this.GroupBox2.Controls.Add(this.CheckBox13);
            this.GroupBox2.Controls.Add(this.CheckBox12);
            this.GroupBox2.Controls.Add(this.CheckBox11);
            this.GroupBox2.Controls.Add(this.CheckBox10);
            this.GroupBox2.Controls.Add(this.CheckBox9);
            this.GroupBox2.Location = new System.Drawing.Point(368, 50);
            this.GroupBox2.Name = "GroupBox2";
            this.GroupBox2.Size = new System.Drawing.Size(260, 40);
            this.GroupBox2.TabIndex = 39;
            this.GroupBox2.TabStop = false;
            this.GroupBox2.Text = "Outputs";
            // 
            // CheckBox10
            // 
            this.CheckBox10.Location = new System.Drawing.Point(38, 17);
            this.CheckBox10.Name = "CheckBox10";
            this.CheckBox10.Size = new System.Drawing.Size(26, 15);
            this.CheckBox10.TabIndex = 6;
            this.CheckBox10.Text = "2";
            this.CheckBox10.UseVisualStyleBackColor = true;
            this.CheckBox10.CheckedChanged += new System.EventHandler(this.CheckBox10_CheckedChanged);
            // 
            // CheckBox9
            // 
            this.CheckBox9.Location = new System.Drawing.Point(6, 17);
            this.CheckBox9.Name = "CheckBox9";
            this.CheckBox9.Size = new System.Drawing.Size(26, 15);
            this.CheckBox9.TabIndex = 5;
            this.CheckBox9.Text = "1";
            this.CheckBox9.UseVisualStyleBackColor = true;
            this.CheckBox9.CheckedChanged += new System.EventHandler(this.CheckBox9_CheckedChanged);
            // 
            // Label9
            // 
            this.Label9.AutoSize = true;
            this.Label9.Location = new System.Drawing.Point(10, 272);
            this.Label9.Name = "Label9";
            this.Label9.Size = new System.Drawing.Size(22, 13);
            this.Label9.TabIndex = 44;
            this.Label9.Text = "- - -";
            // 
            // Button9
            // 
            this.Button9.Location = new System.Drawing.Point(10, 245);
            this.Button9.Name = "Button9";
            this.Button9.Size = new System.Drawing.Size(97, 24);
            this.Button9.TabIndex = 43;
            this.Button9.Text = "DLL Version";
            this.Button9.UseVisualStyleBackColor = true;
            this.Button9.Click += new System.EventHandler(this.Button9_Click);
            // 
            // Timer1
            // 
            this.Timer1.Interval = 50;
            this.Timer1.Tick += new System.EventHandler(this.Timer1_Tick);
            // 
            // Button8
            // 
            this.Button8.Location = new System.Drawing.Point(10, 160);
            this.Button8.Name = "Button8";
            this.Button8.Size = new System.Drawing.Size(97, 24);
            this.Button8.TabIndex = 42;
            this.Button8.Text = "Search Devices";
            this.Button8.UseVisualStyleBackColor = true;
            this.Button8.Click += new System.EventHandler(this.Button8_Click);
            // 
            // RadioButton12
            // 
            this.RadioButton12.AutoSize = true;
            this.RadioButton12.Enabled = false;
            this.RadioButton12.Location = new System.Drawing.Point(24, 120);
            this.RadioButton12.Name = "RadioButton12";
            this.RadioButton12.Size = new System.Drawing.Size(68, 17);
            this.RadioButton12.TabIndex = 40;
            this.RadioButton12.TabStop = true;
            this.RadioButton12.Text = "Device 3";
            this.RadioButton12.UseVisualStyleBackColor = true;
            this.RadioButton12.CheckedChanged += new System.EventHandler(this.RadioButton12_CheckedChanged);
            // 
            // GroupBox10
            // 
            this.GroupBox10.Controls.Add(this.Label9);
            this.GroupBox10.Controls.Add(this.Button9);
            this.GroupBox10.Controls.Add(this.Button8);
            this.GroupBox10.Controls.Add(this.Label8);
            this.GroupBox10.Controls.Add(this.RadioButton12);
            this.GroupBox10.Controls.Add(this.RadioButton11);
            this.GroupBox10.Controls.Add(this.RadioButton10);
            this.GroupBox10.Controls.Add(this.RadioButton9);
            this.GroupBox10.Location = new System.Drawing.Point(646, 7);
            this.GroupBox10.Name = "GroupBox10";
            this.GroupBox10.Size = new System.Drawing.Size(120, 300);
            this.GroupBox10.TabIndex = 54;
            this.GroupBox10.TabStop = false;
            this.GroupBox10.Text = "Multicard Commands";
            // 
            // Label8
            // 
            this.Label8.AutoSize = true;
            this.Label8.Location = new System.Drawing.Point(10, 31);
            this.Label8.Name = "Label8";
            this.Label8.Size = new System.Drawing.Size(97, 13);
            this.Label8.TabIndex = 41;
            this.Label8.Text = "Set Current Device";
            // 
            // RadioButton11
            // 
            this.RadioButton11.AutoSize = true;
            this.RadioButton11.Enabled = false;
            this.RadioButton11.Location = new System.Drawing.Point(24, 97);
            this.RadioButton11.Name = "RadioButton11";
            this.RadioButton11.Size = new System.Drawing.Size(68, 17);
            this.RadioButton11.TabIndex = 39;
            this.RadioButton11.TabStop = true;
            this.RadioButton11.Text = "Device 2";
            this.RadioButton11.UseVisualStyleBackColor = true;
            this.RadioButton11.CheckedChanged += new System.EventHandler(this.RadioButton11_CheckedChanged);
            // 
            // RadioButton10
            // 
            this.RadioButton10.AutoSize = true;
            this.RadioButton10.Enabled = false;
            this.RadioButton10.Location = new System.Drawing.Point(24, 74);
            this.RadioButton10.Name = "RadioButton10";
            this.RadioButton10.Size = new System.Drawing.Size(68, 17);
            this.RadioButton10.TabIndex = 38;
            this.RadioButton10.TabStop = true;
            this.RadioButton10.Text = "Device 1";
            this.RadioButton10.UseVisualStyleBackColor = true;
            this.RadioButton10.CheckedChanged += new System.EventHandler(this.RadioButton10_CheckedChanged);
            // 
            // RadioButton9
            // 
            this.RadioButton9.AutoSize = true;
            this.RadioButton9.Enabled = false;
            this.RadioButton9.Location = new System.Drawing.Point(24, 51);
            this.RadioButton9.Name = "RadioButton9";
            this.RadioButton9.Size = new System.Drawing.Size(68, 17);
            this.RadioButton9.TabIndex = 37;
            this.RadioButton9.TabStop = true;
            this.RadioButton9.Text = "Device 0";
            this.RadioButton9.UseVisualStyleBackColor = true;
            this.RadioButton9.CheckedChanged += new System.EventHandler(this.RadioButton9_CheckedChanged);
            // 
            // GroupBox3
            // 
            this.GroupBox3.Controls.Add(this.CheckBox2);
            this.GroupBox3.Controls.Add(this.CheckBox1);
            this.GroupBox3.Location = new System.Drawing.Point(12, 7);
            this.GroupBox3.Name = "GroupBox3";
            this.GroupBox3.Size = new System.Drawing.Size(108, 44);
            this.GroupBox3.TabIndex = 40;
            this.GroupBox3.TabStop = false;
            this.GroupBox3.Text = "Card Address";
            // 
            // CheckBox2
            // 
            this.CheckBox2.Checked = true;
            this.CheckBox2.CheckState = System.Windows.Forms.CheckState.Checked;
            this.CheckBox2.Location = new System.Drawing.Point(56, 20);
            this.CheckBox2.Name = "CheckBox2";
            this.CheckBox2.Size = new System.Drawing.Size(48, 16);
            this.CheckBox2.TabIndex = 1;
            this.CheckBox2.Text = "SK6";
            // 
            // CheckBox1
            // 
            this.CheckBox1.Checked = true;
            this.CheckBox1.CheckState = System.Windows.Forms.CheckState.Checked;
            this.CheckBox1.Cursor = System.Windows.Forms.Cursors.Default;
            this.CheckBox1.Location = new System.Drawing.Point(8, 20);
            this.CheckBox1.Name = "CheckBox1";
            this.CheckBox1.Size = new System.Drawing.Size(48, 16);
            this.CheckBox1.TabIndex = 0;
            this.CheckBox1.Text = "SK5";
            // 
            // Label4
            // 
            this.Label4.Location = new System.Drawing.Point(12, 276);
            this.Label4.Name = "Label4";
            this.Label4.Size = new System.Drawing.Size(28, 16);
            this.Label4.TabIndex = 14;
            this.Label4.Text = " 00";
            // 
            // GroupBox9
            // 
            this.GroupBox9.Controls.Add(this.Label7);
            this.GroupBox9.Controls.Add(this.VScrollBar4);
            this.GroupBox9.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.GroupBox9.Location = new System.Drawing.Point(304, 7);
            this.GroupBox9.Name = "GroupBox9";
            this.GroupBox9.Size = new System.Drawing.Size(44, 300);
            this.GroupBox9.TabIndex = 52;
            this.GroupBox9.TabStop = false;
            this.GroupBox9.Text = "AD2";
            // 
            // Label7
            // 
            this.Label7.Location = new System.Drawing.Point(12, 276);
            this.Label7.Name = "Label7";
            this.Label7.Size = new System.Drawing.Size(28, 16);
            this.Label7.TabIndex = 14;
            this.Label7.Text = " 00";
            // 
            // VScrollBar4
            // 
            this.VScrollBar4.LargeChange = 1;
            this.VScrollBar4.Location = new System.Drawing.Point(14, 20);
            this.VScrollBar4.Maximum = 255;
            this.VScrollBar4.Name = "VScrollBar4";
            this.VScrollBar4.Size = new System.Drawing.Size(16, 252);
            this.VScrollBar4.TabIndex = 13;
            this.VScrollBar4.Value = 255;
            // 
            // GroupBox8
            // 
            this.GroupBox8.Controls.Add(this.Label6);
            this.GroupBox8.Controls.Add(this.VScrollBar3);
            this.GroupBox8.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.GroupBox8.Location = new System.Drawing.Point(256, 7);
            this.GroupBox8.Name = "GroupBox8";
            this.GroupBox8.Size = new System.Drawing.Size(44, 300);
            this.GroupBox8.TabIndex = 51;
            this.GroupBox8.TabStop = false;
            this.GroupBox8.Text = "AD1";
            // 
            // Label6
            // 
            this.Label6.Location = new System.Drawing.Point(12, 276);
            this.Label6.Name = "Label6";
            this.Label6.Size = new System.Drawing.Size(28, 16);
            this.Label6.TabIndex = 14;
            this.Label6.Text = " 00";
            // 
            // VScrollBar3
            // 
            this.VScrollBar3.LargeChange = 1;
            this.VScrollBar3.Location = new System.Drawing.Point(14, 20);
            this.VScrollBar3.Maximum = 255;
            this.VScrollBar3.Name = "VScrollBar3";
            this.VScrollBar3.Size = new System.Drawing.Size(16, 252);
            this.VScrollBar3.TabIndex = 13;
            this.VScrollBar3.Value = 255;
            // 
            // VScrollBar1
            // 
            this.VScrollBar1.LargeChange = 1;
            this.VScrollBar1.Location = new System.Drawing.Point(14, 20);
            this.VScrollBar1.Maximum = 255;
            this.VScrollBar1.Name = "VScrollBar1";
            this.VScrollBar1.Size = new System.Drawing.Size(16, 252);
            this.VScrollBar1.TabIndex = 13;
            this.VScrollBar1.Value = 255;
            this.VScrollBar1.Scroll += new System.Windows.Forms.ScrollEventHandler(this.VScrollBar1_Scroll);
            // 
            // GroupBox7
            // 
            this.GroupBox7.Controls.Add(this.Label5);
            this.GroupBox7.Controls.Add(this.VScrollBar2);
            this.GroupBox7.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.GroupBox7.Location = new System.Drawing.Point(192, 7);
            this.GroupBox7.Name = "GroupBox7";
            this.GroupBox7.Size = new System.Drawing.Size(44, 300);
            this.GroupBox7.TabIndex = 50;
            this.GroupBox7.TabStop = false;
            this.GroupBox7.Text = "DA2";
            // 
            // Label5
            // 
            this.Label5.Location = new System.Drawing.Point(12, 276);
            this.Label5.Name = "Label5";
            this.Label5.Size = new System.Drawing.Size(28, 16);
            this.Label5.TabIndex = 14;
            this.Label5.Text = " 00";
            // 
            // VScrollBar2
            // 
            this.VScrollBar2.LargeChange = 1;
            this.VScrollBar2.Location = new System.Drawing.Point(14, 20);
            this.VScrollBar2.Maximum = 255;
            this.VScrollBar2.Name = "VScrollBar2";
            this.VScrollBar2.Size = new System.Drawing.Size(16, 252);
            this.VScrollBar2.TabIndex = 13;
            this.VScrollBar2.Value = 255;
            this.VScrollBar2.Scroll += new System.Windows.Forms.ScrollEventHandler(this.VScrollBar2_Scroll);
            // 
            // GroupBox6
            // 
            this.GroupBox6.Controls.Add(this.Label4);
            this.GroupBox6.Controls.Add(this.VScrollBar1);
            this.GroupBox6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.GroupBox6.Location = new System.Drawing.Point(144, 7);
            this.GroupBox6.Name = "GroupBox6";
            this.GroupBox6.Size = new System.Drawing.Size(44, 300);
            this.GroupBox6.TabIndex = 49;
            this.GroupBox6.TabStop = false;
            this.GroupBox6.Text = "DA1";
            // 
            // Button7
            // 
            this.Button7.Location = new System.Drawing.Point(12, 223);
            this.Button7.Name = "Button7";
            this.Button7.Size = new System.Drawing.Size(108, 24);
            this.Button7.TabIndex = 47;
            this.Button7.Text = "Set All Analog";
            this.Button7.Click += new System.EventHandler(this.Button7_Click);
            // 
            // Button5
            // 
            this.Button5.Location = new System.Drawing.Point(12, 193);
            this.Button5.Name = "Button5";
            this.Button5.Size = new System.Drawing.Size(108, 24);
            this.Button5.TabIndex = 46;
            this.Button5.Text = "Clear All Digital";
            this.Button5.Click += new System.EventHandler(this.Button5_Click);
            // 
            // Button6
            // 
            this.Button6.Location = new System.Drawing.Point(12, 253);
            this.Button6.Name = "Button6";
            this.Button6.Size = new System.Drawing.Size(108, 24);
            this.Button6.TabIndex = 48;
            this.Button6.Text = "Clear All Analog";
            this.Button6.Click += new System.EventHandler(this.Button6_Click);
            // 
            // RadioButton4
            // 
            this.RadioButton4.AutoSize = true;
            this.RadioButton4.Location = new System.Drawing.Point(9, 159);
            this.RadioButton4.Name = "RadioButton4";
            this.RadioButton4.Size = new System.Drawing.Size(62, 17);
            this.RadioButton4.TabIndex = 6;
            this.RadioButton4.Text = "1000ms";
            this.RadioButton4.UseVisualStyleBackColor = true;
            this.RadioButton4.CheckedChanged += new System.EventHandler(this.RadioButton4_CheckedChanged);
            // 
            // RadioButton3
            // 
            this.RadioButton3.AutoSize = true;
            this.RadioButton3.Location = new System.Drawing.Point(9, 136);
            this.RadioButton3.Name = "RadioButton3";
            this.RadioButton3.Size = new System.Drawing.Size(50, 17);
            this.RadioButton3.TabIndex = 5;
            this.RadioButton3.Text = "10ms";
            this.RadioButton3.UseVisualStyleBackColor = true;
            this.RadioButton3.CheckedChanged += new System.EventHandler(this.RadioButton3_CheckedChanged);
            // 
            // RadioButton2
            // 
            this.RadioButton2.AutoSize = true;
            this.RadioButton2.Checked = true;
            this.RadioButton2.Location = new System.Drawing.Point(9, 113);
            this.RadioButton2.Name = "RadioButton2";
            this.RadioButton2.Size = new System.Drawing.Size(44, 17);
            this.RadioButton2.TabIndex = 4;
            this.RadioButton2.TabStop = true;
            this.RadioButton2.Text = "2ms";
            this.RadioButton2.UseVisualStyleBackColor = true;
            this.RadioButton2.CheckedChanged += new System.EventHandler(this.RadioButton2_CheckedChanged);
            // 
            // RadioButton1
            // 
            this.RadioButton1.AutoSize = true;
            this.RadioButton1.Location = new System.Drawing.Point(9, 90);
            this.RadioButton1.Name = "RadioButton1";
            this.RadioButton1.Size = new System.Drawing.Size(44, 17);
            this.RadioButton1.TabIndex = 3;
            this.RadioButton1.Text = "0ms";
            this.RadioButton1.UseVisualStyleBackColor = true;
            this.RadioButton1.CheckedChanged += new System.EventHandler(this.RadioButton1_CheckedChanged);
            // 
            // Label2
            // 
            this.Label2.Location = new System.Drawing.Point(6, 71);
            this.Label2.Name = "Label2";
            this.Label2.Size = new System.Drawing.Size(104, 16);
            this.Label2.TabIndex = 2;
            this.Label2.Text = "Debounce Time";
            // 
            // Button2
            // 
            this.Button2.Location = new System.Drawing.Point(6, 44);
            this.Button2.Name = "Button2";
            this.Button2.Size = new System.Drawing.Size(104, 24);
            this.Button2.TabIndex = 1;
            this.Button2.Text = "Reset";
            this.Button2.Click += new System.EventHandler(this.Button2_Click);
            // 
            // TextBox1
            // 
            this.TextBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TextBox1.Location = new System.Drawing.Point(6, 19);
            this.TextBox1.Name = "TextBox1";
            this.TextBox1.Size = new System.Drawing.Size(104, 20);
            this.TextBox1.TabIndex = 0;
            this.TextBox1.Text = "0";
            // 
            // Button4
            // 
            this.Button4.Location = new System.Drawing.Point(12, 163);
            this.Button4.Name = "Button4";
            this.Button4.Size = new System.Drawing.Size(108, 24);
            this.Button4.TabIndex = 45;
            this.Button4.Text = "Set All Digital";
            this.Button4.Click += new System.EventHandler(this.Button4_Click);
            // 
            // Timer2
            // 
            this.Timer2.Tick += new System.EventHandler(this.Timer2_Tick);
            // 
            // GroupBox1
            // 
            this.GroupBox1.Controls.Add(this.CheckBox8);
            this.GroupBox1.Controls.Add(this.CheckBox7);
            this.GroupBox1.Controls.Add(this.CheckBox6);
            this.GroupBox1.Controls.Add(this.CheckBox5);
            this.GroupBox1.Controls.Add(this.CheckBox4);
            this.GroupBox1.Location = new System.Drawing.Point(368, 7);
            this.GroupBox1.Name = "GroupBox1";
            this.GroupBox1.Size = new System.Drawing.Size(172, 40);
            this.GroupBox1.TabIndex = 38;
            this.GroupBox1.TabStop = false;
            this.GroupBox1.Text = "Inputs";
            // 
            // CheckBox8
            // 
            this.CheckBox8.Location = new System.Drawing.Point(134, 17);
            this.CheckBox8.Name = "CheckBox8";
            this.CheckBox8.Size = new System.Drawing.Size(26, 15);
            this.CheckBox8.TabIndex = 4;
            this.CheckBox8.Text = "5";
            this.CheckBox8.UseVisualStyleBackColor = true;
            // 
            // CheckBox7
            // 
            this.CheckBox7.Location = new System.Drawing.Point(102, 17);
            this.CheckBox7.Name = "CheckBox7";
            this.CheckBox7.Size = new System.Drawing.Size(26, 15);
            this.CheckBox7.TabIndex = 3;
            this.CheckBox7.Text = "4";
            this.CheckBox7.UseVisualStyleBackColor = true;
            // 
            // CheckBox6
            // 
            this.CheckBox6.Location = new System.Drawing.Point(70, 17);
            this.CheckBox6.Name = "CheckBox6";
            this.CheckBox6.Size = new System.Drawing.Size(26, 15);
            this.CheckBox6.TabIndex = 2;
            this.CheckBox6.Text = "3";
            this.CheckBox6.UseVisualStyleBackColor = true;
            // 
            // CheckBox5
            // 
            this.CheckBox5.Location = new System.Drawing.Point(38, 17);
            this.CheckBox5.Name = "CheckBox5";
            this.CheckBox5.Size = new System.Drawing.Size(26, 15);
            this.CheckBox5.TabIndex = 1;
            this.CheckBox5.Text = "2";
            this.CheckBox5.UseVisualStyleBackColor = true;
            // 
            // CheckBox4
            // 
            this.CheckBox4.Location = new System.Drawing.Point(6, 17);
            this.CheckBox4.Name = "CheckBox4";
            this.CheckBox4.Size = new System.Drawing.Size(26, 15);
            this.CheckBox4.TabIndex = 0;
            this.CheckBox4.Text = "1";
            this.CheckBox4.UseVisualStyleBackColor = true;
            // 
            // GroupBox4
            // 
            this.GroupBox4.Controls.Add(this.RadioButton4);
            this.GroupBox4.Controls.Add(this.RadioButton3);
            this.GroupBox4.Controls.Add(this.RadioButton2);
            this.GroupBox4.Controls.Add(this.RadioButton1);
            this.GroupBox4.Controls.Add(this.Label2);
            this.GroupBox4.Controls.Add(this.Button2);
            this.GroupBox4.Controls.Add(this.TextBox1);
            this.GroupBox4.Location = new System.Drawing.Point(368, 123);
            this.GroupBox4.Name = "GroupBox4";
            this.GroupBox4.Size = new System.Drawing.Size(117, 184);
            this.GroupBox4.TabIndex = 43;
            this.GroupBox4.TabStop = false;
            this.GroupBox4.Text = "Counter1";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(771, 311);
            this.Controls.Add(this.CheckBox3);
            this.Controls.Add(this.Label1);
            this.Controls.Add(this.GroupBox5);
            this.Controls.Add(this.Button1);
            this.Controls.Add(this.GroupBox2);
            this.Controls.Add(this.GroupBox10);
            this.Controls.Add(this.GroupBox3);
            this.Controls.Add(this.GroupBox9);
            this.Controls.Add(this.GroupBox8);
            this.Controls.Add(this.GroupBox7);
            this.Controls.Add(this.GroupBox6);
            this.Controls.Add(this.Button7);
            this.Controls.Add(this.Button5);
            this.Controls.Add(this.Button6);
            this.Controls.Add(this.Button4);
            this.Controls.Add(this.GroupBox1);
            this.Controls.Add(this.GroupBox4);
            this.Name = "Form1";
            this.Text = "Form1";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Form1_FormClosed);
            this.GroupBox5.ResumeLayout(false);
            this.GroupBox5.PerformLayout();
            this.GroupBox2.ResumeLayout(false);
            this.GroupBox10.ResumeLayout(false);
            this.GroupBox10.PerformLayout();
            this.GroupBox3.ResumeLayout(false);
            this.GroupBox9.ResumeLayout(false);
            this.GroupBox8.ResumeLayout(false);
            this.GroupBox7.ResumeLayout(false);
            this.GroupBox6.ResumeLayout(false);
            this.GroupBox1.ResumeLayout(false);
            this.GroupBox4.ResumeLayout(false);
            this.GroupBox4.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        internal System.Windows.Forms.CheckBox CheckBox16;
        internal System.Windows.Forms.CheckBox CheckBox3;
        internal System.Windows.Forms.Label Label1;
        internal System.Windows.Forms.CheckBox CheckBox15;
        internal System.Windows.Forms.GroupBox GroupBox5;
        internal System.Windows.Forms.RadioButton RadioButton5;
        internal System.Windows.Forms.RadioButton RadioButton6;
        internal System.Windows.Forms.RadioButton RadioButton7;
        internal System.Windows.Forms.RadioButton RadioButton8;
        internal System.Windows.Forms.Label Label3;
        internal System.Windows.Forms.Button Button3;
        internal System.Windows.Forms.TextBox TextBox2;
        internal System.Windows.Forms.CheckBox CheckBox14;
        internal System.Windows.Forms.CheckBox CheckBox12;
        internal System.Windows.Forms.Button Button1;
        internal System.Windows.Forms.CheckBox CheckBox13;
        internal System.Windows.Forms.CheckBox CheckBox11;
        internal System.Windows.Forms.GroupBox GroupBox2;
        internal System.Windows.Forms.CheckBox CheckBox10;
        internal System.Windows.Forms.CheckBox CheckBox9;
        internal System.Windows.Forms.Label Label9;
        internal System.Windows.Forms.Button Button9;
        internal System.Windows.Forms.Timer Timer1;
        internal System.Windows.Forms.Button Button8;
        internal System.Windows.Forms.RadioButton RadioButton12;
        internal System.Windows.Forms.GroupBox GroupBox10;
        internal System.Windows.Forms.Label Label8;
        internal System.Windows.Forms.RadioButton RadioButton11;
        internal System.Windows.Forms.RadioButton RadioButton10;
        internal System.Windows.Forms.RadioButton RadioButton9;
        internal System.Windows.Forms.GroupBox GroupBox3;
        internal System.Windows.Forms.CheckBox CheckBox2;
        internal System.Windows.Forms.CheckBox CheckBox1;
        internal System.Windows.Forms.Label Label4;
        internal System.Windows.Forms.GroupBox GroupBox9;
        internal System.Windows.Forms.Label Label7;
        internal System.Windows.Forms.VScrollBar VScrollBar4;
        internal System.Windows.Forms.GroupBox GroupBox8;
        internal System.Windows.Forms.Label Label6;
        internal System.Windows.Forms.VScrollBar VScrollBar3;
        internal System.Windows.Forms.VScrollBar VScrollBar1;
        internal System.Windows.Forms.GroupBox GroupBox7;
        internal System.Windows.Forms.Label Label5;
        internal System.Windows.Forms.VScrollBar VScrollBar2;
        internal System.Windows.Forms.GroupBox GroupBox6;
        internal System.Windows.Forms.Button Button7;
        internal System.Windows.Forms.Button Button5;
        internal System.Windows.Forms.Button Button6;
        internal System.Windows.Forms.RadioButton RadioButton4;
        internal System.Windows.Forms.RadioButton RadioButton3;
        internal System.Windows.Forms.RadioButton RadioButton2;
        internal System.Windows.Forms.RadioButton RadioButton1;
        internal System.Windows.Forms.Label Label2;
        internal System.Windows.Forms.Button Button2;
        internal System.Windows.Forms.TextBox TextBox1;
        internal System.Windows.Forms.Button Button4;
        internal System.Windows.Forms.Timer Timer2;
        internal System.Windows.Forms.GroupBox GroupBox1;
        internal System.Windows.Forms.CheckBox CheckBox8;
        internal System.Windows.Forms.CheckBox CheckBox7;
        internal System.Windows.Forms.CheckBox CheckBox6;
        internal System.Windows.Forms.CheckBox CheckBox5;
        internal System.Windows.Forms.CheckBox CheckBox4;
        internal System.Windows.Forms.GroupBox GroupBox4;
    }
}

